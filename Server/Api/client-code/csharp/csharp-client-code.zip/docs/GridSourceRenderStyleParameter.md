# IO.Swagger.Model.GridSourceRenderStyleParameter
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Value** | **double?** |  | [optional] 
**Min** | **double?** |  | [optional] 
**Max** | **double?** |  | [optional] 
**Color** | **string** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

