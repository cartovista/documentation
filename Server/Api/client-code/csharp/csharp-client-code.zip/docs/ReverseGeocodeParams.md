# IO.Swagger.Model.ReverseGeocodeParams
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Longitude** | **string** |  | [optional] 
**Latitude** | **string** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

