# IO.Swagger.Model.Layer
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**UniqueIdentifier** | **string** |  | [optional] 
**CreationTime** | **string** |  | [optional] 
**DataTableUniqueIdentifier** | **string** |  | [optional] 
**Description** | **string** |  | [optional] 
**GeometryType** | **string** |  | [optional] 
**Metadata** | **string** |  | [optional] 
**ModifiedTime** | **string** |  | [optional] 
**Name** | **string** |  | [optional] 
**Proj4** | **string** |  | [optional] 
**RowCount** | **int?** |  | [optional] 
**SystemIdentifier** | **Guid?** |  | [optional] 
**UniqueIdDataColumn** | **Guid?** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

