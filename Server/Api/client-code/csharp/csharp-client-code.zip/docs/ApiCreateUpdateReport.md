# IO.Swagger.Model.ApiCreateUpdateReport
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**UpdateCount** | **int?** |  | [optional] 
**CreateCount** | **int?** |  | [optional] 
**InsertedIdentifiers** | **List&lt;string&gt;** |  | [optional] 
**UpdatedIdentifiers** | **List&lt;string&gt;** |  | [optional] 
**ErrorCount** | **int?** |  | [optional] 
**ErrorDetails** | [**List&lt;ErrorDetail&gt;**](ErrorDetail.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

