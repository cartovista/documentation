# IO.Swagger.Model.CreateViewByExpressionParameters
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Title** | **string** | The view title. | [optional] 
**Expression** | **string** | The view expression. Column friendly identifier can be used and must be surrounded by square bracket.  Ex: [Name] &#x3D; &#39;Test&#39; | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

