# IO.Swagger.Model.DataRow
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Identifier** | **string** |  | [optional] 
**Values** | **List&lt;Object&gt;** |  | [optional] 
**DataColumnsIdentifiers** | **List&lt;string&gt;** |  | [optional] 
**DataColumnsSystemIdentifiers** | **List&lt;Guid?&gt;** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

