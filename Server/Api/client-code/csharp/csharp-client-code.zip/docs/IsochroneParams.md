# IO.Swagger.Model.IsochroneParams
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Longitude** | **double?** |  | [optional] 
**Latitude** | **double?** |  | [optional] 
**Range** | **double?** |  | [optional] 
**RangeType** | **string** |  | [optional] 
**Mode** | **string** |  | [optional] 
**DepartureTime** | **string** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

