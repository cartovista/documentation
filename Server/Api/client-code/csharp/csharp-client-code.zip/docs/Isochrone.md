# IO.Swagger.Model.Isochrone
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Longitude** | **double?** |  | [optional] 
**Latitude** | **double?** |  | [optional] 
**Range** | **string** |  | [optional] 
**RangeType** | **string** |  | [optional] 
**Mode** | **string** |  | [optional] 
**DepartureTime** | **string** |  | [optional] 
**IsolineCoordinates** | **List&lt;double?&gt;** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

