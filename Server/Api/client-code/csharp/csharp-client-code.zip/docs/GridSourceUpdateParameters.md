# IO.Swagger.Model.GridSourceUpdateParameters
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**UniqueIdentifier** | **string** |  | [optional] 
**Name** | **string** |  | [optional] 
**Description** | **string** |  | [optional] 
**Timestamp** | **DateTime?** |  | [optional] 
**NoDataEnabled** | **bool?** |  | [optional] 
**NoDataValue** | **string** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

