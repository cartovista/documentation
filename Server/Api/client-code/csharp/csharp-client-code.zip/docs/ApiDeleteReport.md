# IO.Swagger.Model.ApiDeleteReport
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**DeleteCount** | **int?** |  | [optional] 
**DeletedIdentifiers** | **List&lt;string&gt;** |  | [optional] 
**ErrorCount** | **int?** |  | [optional] 
**ErrorDetails** | [**List&lt;ErrorDetail&gt;**](ErrorDetail.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

