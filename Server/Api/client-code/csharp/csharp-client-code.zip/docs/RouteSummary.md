# IO.Swagger.Model.RouteSummary
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**OriginLatitude** | **double?** |  | [optional] 
**OriginLongitude** | **double?** |  | [optional] 
**DestinationLatitude** | **double?** |  | [optional] 
**DestinationLongitude** | **double?** |  | [optional] 
**DriveDistanceMeters** | **int?** |  | [optional] 
**DriveTimeMinutes** | **int?** |  | [optional] 
**Coordinates** | **List&lt;double?&gt;** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

