# IO.Swagger.Model.LayerCreateParameter
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Identifier** | **string** |  | [optional] 
**Proj4** | **string** |  | [optional] 
**Name** | **string** |  | [optional] 
**Metadata** | **string** |  | [optional] 
**GeometryType** | **string** |  | [optional] 
**Description** | **string** |  | [optional] 
**VectorTiling** | **bool?** |  | [optional] 
**SystemIdentifier** | **Guid?** |  | [optional] 
**DataTableSystemIdentifier** | **Guid?** |  | [optional] 
**FeatureIdColumnSystemIdentifier** | **Guid?** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

