# IO.Swagger.Model.BoundingBox
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Minx** | **double?** |  | [optional] 
**Miny** | **double?** |  | [optional] 
**Maxx** | **double?** |  | [optional] 
**Maxy** | **double?** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

