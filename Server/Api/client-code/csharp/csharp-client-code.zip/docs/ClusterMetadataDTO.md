# IO.Swagger.Model.ClusterMetadataDTO
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ClusterStatus** | **int?** |  | [optional] 
**FeatureGroupTableRef** | **string** |  | [optional] 
**FeatureGroupXREFTableRef** | **string** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

