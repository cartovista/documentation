# IO.Swagger.Model.Extent
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**MinX** | **double?** |  | [optional] 
**MinY** | **double?** |  | [optional] 
**MaxX** | **double?** |  | [optional] 
**MaxY** | **double?** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

