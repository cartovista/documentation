# IO.Swagger.Model.PermissionPairComplexDTO
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**User** | [**SecurityIdentityDTO**](SecurityIdentityDTO.md) |  | [optional] 
**PermissionName** | **string** |  | [optional] 
**SecureObjectGuid** | **Guid?** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

