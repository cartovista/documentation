# IO.Swagger.Model.GridLayer
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**UniqueIdentifier** | **string** |  | [optional] 
**Description** | **string** |  | [optional] 
**Metadata** | **string** |  | [optional] 
**Proj4** | **string** |  | [optional] 
**Units** | **string** |  | [optional] 
**Precision** | **int?** |  | [optional] 
**GridSourceCount** | **int?** |  | [optional] 
**Name** | **string** |  | [optional] 
**CreationTime** | **DateTime?** |  | [optional] 
**ModifiedTime** | **DateTime?** |  | [optional] 
**SystemIdentifier** | **Guid?** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

