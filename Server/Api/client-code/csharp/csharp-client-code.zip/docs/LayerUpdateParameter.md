# IO.Swagger.Model.LayerUpdateParameter
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Name** | **string** |  | [optional] 
**Metadata** | **string** |  | [optional] 
**Description** | **string** |  | [optional] 
**VectorTiling** | **bool?** |  | [optional] 
**DataColumns** | [**List&lt;DataColumnUpdateParameterExtended&gt;**](DataColumnUpdateParameterExtended.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

