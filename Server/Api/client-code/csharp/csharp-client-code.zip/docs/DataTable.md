# IO.Swagger.Model.DataTable
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**UniqueIdentifier** | **string** |  | [optional] 
**SystemIdentifier** | **Guid?** |  | [optional] 
**UniqueIdDataColumn** | **Guid?** |  | [optional] 
**Name** | **string** |  | [optional] 
**Description** | **string** |  | [optional] 
**Metadata** | **string** |  | [optional] 
**RowCount** | **int?** |  | [optional] 
**CreationTime** | **string** |  | [optional] 
**ModifiedTime** | **string** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

