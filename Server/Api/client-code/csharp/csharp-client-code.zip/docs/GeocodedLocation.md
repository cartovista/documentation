# IO.Swagger.Model.GeocodedLocation
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Longitude** | **double?** |  | [optional] 
**Latitude** | **double?** |  | [optional] 
**Address** | **string** |  | [optional] 
**BoundingBox** | [**BoundingBox**](BoundingBox.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

