# IO.Swagger.Model.GridSourceRenderParameter
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Extent** | **List&lt;double?&gt;** |  | [optional] 
**Width** | **int?** |  | [optional] 
**Height** | **int?** |  | [optional] 
**IsLinearRender** | **bool?** |  | [optional] 
**Styles** | [**List&lt;GridSourceRenderStyleParameter&gt;**](GridSourceRenderStyleParameter.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

